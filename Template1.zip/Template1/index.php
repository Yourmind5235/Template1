<!-- Ini bisa di buka Dengan memakai XAMPP Dan Nyalakan Apache Habis itu ketik di chrome "localhost" -->

<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">

    <title>Server Name | Home</title>
    <link rel="icon" href="favicon.ico"> <!-- Icons -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/mobile.css">
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Didact+Gothic">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="js/scripts.min.js"></script>
    <script src="js/smoothscroll.js"></script>

</head>

<body>

    <div id="top-bar">
        <div id="server-join">
            <p>Come join us: <span>Server IP</span></p>
        </div>
        <div id="server-ip">
            <script>
                $.getJSON('http://mcping.net/api/Server IP/online', function(status) {
                    document.querySelector('.players-online').innerHTML = '<span class="color">' + status.online + '</span> Players Online';
                });
            </script>
            <span class="players-online"><span class="color">0</span> Players join on <a href="">"Server Name"</a></span>
        </div>
    </div>
    <header role="banner">

        <div id="logo">
            <img src="img/background.jpg" alt="Server Logo" title="Server Logo" width="800" height="400">
            <!-- Setelah Pasang Server logonya Widht Sama Heightnya Di Hapus Itu Logonya 800 x 400 jangan yang 1920 x 1080 -->
        </div>

        <nav role="navigation">
            <ul>
                <li><a href="#yourlinkgoeshere"><span>FORUM</span></a></li>
                <li><a href="#yourlinkgoeshere"><span>STORE</span></a></li>
                <li><a href="#yourlinkgoeshere"><span>STAFF</span></a></li>
                <li><a href="#yourlinkgoeshere"><span>VOTE</span></a></li>
                <li><a href="#yourlinkgoeshere"><span>BANS</span></a></li>
            </ul>
        </nav>
    </header>

</body>

</html>